from django.apps import AppConfig


class PredictioninfopageConfig(AppConfig):
    name = 'predictionInfoPage'
