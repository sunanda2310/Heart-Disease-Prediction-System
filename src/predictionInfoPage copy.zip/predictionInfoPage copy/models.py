from django.db import models

# Create your models here.
class predictionInfo(models.Model):
    age=models.IntegerField()
    sex=models.CharField(max_length=10) # max_length = required
    chestPainType=models.IntegerField()
    RestingECG=models.IntegerField()
    HR=models.IntegerField()
    BloodSugar=models.IntegerField(blank=False, null=True)
    testbool=models.BooleanField(null=False) #null=True, default=True
