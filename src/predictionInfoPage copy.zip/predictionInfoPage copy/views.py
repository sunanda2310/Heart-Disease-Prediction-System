from django.http import HttpResponse
from django.shortcuts import render
from .models import predictionInfo
# Create your views here.

def product_detail_view(request):
    obj = predictionInfo.objects.get(id=1)
    # context = {
    #     'age': obj.age,
    #     'sex': obj.sex
    # }
    context = {
         'object': obj
     }
    return render(request, "detail.html", context)

